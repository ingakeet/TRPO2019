INSERT INTO adeptus_saroritas VALUES("Селестианка", 36, "AS_1.jpg");
INSERT INTO adeptus_saroritas VALUES("Сестра битвы", 34, "AS_2.jpg");
INSERT INTO adeptus_saroritas VALUES("Святая-во-плоти", 12, "AS_3.jpg");
INSERT INTO adeptus_saroritas VALUES("Канонисса", 56, "AS_4.jpg");
INSERT INTO adeptus_saroritas VALUES("Серафима", 124, "AS_5.jpg");
